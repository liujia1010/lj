<?php
phpinfo();
/**
 * 多行注释
 * 
 */

