<?php
$string = "houdunren.com";

// 用header设置字符编码
header("Content-type:text/html;charset=utf-8");

echo "后盾人的网址 {$string}hello";