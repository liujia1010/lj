<?php
namespace Model;
function show(){
	echo "我是Model你好";
}