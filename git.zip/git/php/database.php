<?php
return [
	'hOst'=> '127.0.0.1',
	'TyPe'=> 'mysql',
	'cache'=> [
		'hOSt' => '112.11.221.12',
		'user' => 'liujia'
	]
];