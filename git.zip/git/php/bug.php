<?php
//000000000000
 exit();?>
think_serialize:O:16:"think\Collection":1:{s:8:" * items";a:0:{}}