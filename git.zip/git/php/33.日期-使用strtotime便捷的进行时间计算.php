<?php

// strtotime()方法可以把标准的时间格式转换成时间戳
echo strtotime('2024-12-23');

echo '<hr/>';

echo strtotime("NOW");

echo '<hr/>';

echo strtotime('+1 year');
