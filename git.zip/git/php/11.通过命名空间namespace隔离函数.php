<?php
include '11.1.php';
include '11.2.php';

User\show();
echo '<hr/>';
Model\show();

