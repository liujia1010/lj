<?php
// 数组的声明
$arr = array(); // 第一种

$arr1 = [1,2,3]; // 第二种，索引数组——下标从0开始自动生成

$arr2 = ['title'=>'Visual Studio'];  // 关联数组，键值对形式