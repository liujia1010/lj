<?php
include'1.html';

@include 'default.html';

@require('default.html');