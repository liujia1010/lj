<?php

$arr = ['刘嘉','知行'];

echo current($arr);  //取出第一个数组元素
echo "<hr/>";
echo next($arr);  // 取出下一个数组元素
echo "<hr/>";
echo prev($arr); // 取出上一个数组元素
