<?php
namespace User;
function show(){
	echo "我是User你好";
}