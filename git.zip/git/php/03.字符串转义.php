<?php
// 利用\+对应字符使对应字符显示出来
$string = "刘嘉 \"liujia.com\"";
echo $string;

// \n 换行符  \t 制表符