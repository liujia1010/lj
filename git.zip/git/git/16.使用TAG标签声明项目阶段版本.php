git tag 标签名 —— 给当前版本打一个标签
git tag —— 显示所有的标签