git stash —— 将git add 提交的文件存储在缓存区
git stash apply —— 将缓存区的文件恢复添加状态
git stash list —— 查看所有的缓存区
git stash drop 缓存区名字  —— 删除对应的缓存区
